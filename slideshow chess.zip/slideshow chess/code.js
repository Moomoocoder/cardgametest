let current = 0;let current2 = 0;
const slide = document.getElementById("slide");
